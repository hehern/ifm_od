/**
  *vehicle.h
  *brief:
  *author:Jianlin Zhang
  *date:20170608
  **/

#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>

#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include "draw.h"

namespace Vehicle
{
class Vehicle
{
public:
  double curvature_V; //center_y^2+wheelbase^2=1/curvature_V^2      //曲率
  double velocity; //the real velocity of vehicle,estimate from encoder and other sensors    //速度
  double wheelbase;      //wheel base         //轴距
  double front_overhang; //front overhang     //车前方
  double rear_overhang;  //rear overhang      //车后方
  
  Vehicle(ros::NodeHandle node_handle, ros::NodeHandle private_node_handle);
  ~Vehicle() {}
  void update(double steering_new, double velocity_new);
  void draw_vehicle(ros::Publisher &vehicle_draw_publisher); //draw vehicle in rviz

private:
  /*───────────────────────────────────────────────────────────────────────
description:
the origin of axis system of vehicle is in the middle, the front and the
bottom of vehicle. X axis is forward. Y axis is leftward. And Z axis is
upward. It just look like this:
                            ↑x
                  y ←┌──────┼──────┐
                    ┌┤             ├┐
                    ||             ||
                    └┤  /¯¯\       ├┘
                     |  \__/       |
                     |             |
                    ┌┤             ├┐
                    ||             ||
                    └┤             ├┘
                     └─────────────┘
───────────────────────────────────────────────────────────────────────*/
  //vehicle's stable parameter
  double width;          //total width of vehicle
  double height;         //height of vehicle
  double ackerman_rate; //actural steering=read_steering*acerman_rate
  //For more accuricy, we need calculate wheel trunning angle according to Ackerman
  //vehicle's status
  double steering; //steering angle
  double steer_offset;
  //ros related variable
  std::string frame_id;
  //functions declare
};
} //namespace Vehicle
#endif
