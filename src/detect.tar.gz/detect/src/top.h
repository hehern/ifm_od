/**
  *top.h
  *brief:top layer of software
  *author:Jianlin Zhang
  *date:20171031
  **/

#include <functional>
#include <ros/ros.h>
#include <can_msgs/Frame.h>
#include <std_msgs/Float32.h>
#include "vehicle.h"
#include "area.h"
#include "collision_detect.h"
#include "detect.h"

namespace Vehicle
{
class Top
{
public:
  Top(ros::NodeHandle node_handle, ros::NodeHandle private_node_handle);
  ~Top(){};

private:
  bool is_displaying;
  bool is_online_running;
  Vehicle vehicle;                                 //画车，以及更新车辆信息
  Collision_detect collision_detect;               //判断车前区域，以及区域内点的个数
  Area slow_area_1;                                //减速区域1
  Area slow_area_2;
  Area stop_area;                                  //停车区域
  Area stop_area_2;
  Lidar::Detect detect;                            //障碍物检测代码

  std::string frame_id;
  ros::Subscriber can_subscriber; //receive CAN bus data
  ros::Subscriber pcl_subscriber;  //receive lidar point cloud data

  ros::Publisher vehicle_draw_publisher; //draw vehicle in rviz with line list
  ros::Publisher stop_area_draw_publisher; //draw stop area in rviz with line list
  ros::Publisher stop_area_2_draw_publisher; //draw stop area in rviz with line list
  ros::Publisher slow_area_1_draw_publisher; //draw slow area 1 in rviz with line list
  ros::Publisher slow_area_2_draw_publisher; //draw slow area 2 in rviz with line list
  ros::Publisher obstacle_pointcloud_publisher;
  ros::Publisher grid_draw_publisher;
  ros::Publisher can_publisher;

  void can_callback(const can_msgs::Frame::ConstPtr &rec);
  void point_cloud_callback(const VPointCloud::ConstPtr &rec);
}; //class Top
} //namespace vehicle