/**
  *detect.h
  *brief: detect obstacle via lidar
  *author:Jianlin Zhang
  *date:20180521
  **/

#ifndef DETECT_H
#define DETECT_H
#define _USE_MATH_DEFINES //use constant number defined in math.h
#include <cmath>
#include <ros/ros.h>
#include <eigen3/Eigen/Geometry>
#include "velodyne.h"
#include "area.h"

namespace Lidar
{
const double M_2PI=2*M_PI;
struct Lidar
{
  double x;
  double y;
  double z;
  double roll;
  double pitch;
  double yaw;
  size_t beams;
  size_t points_per_beam;
};
class Detect
{
public:
  Detect(ros::NodeHandle nh, ros::NodeHandle pnh, std::string prefix);
  ~Detect(){};
  void remove_ground(const VPointCloud::ConstPtr &pcl_in,VPointCloud::Ptr pcl_out);
  void remove_ground(const VPointCloud::ConstPtr &pcl_in,VPointCloud::Ptr pcl_out,Vehicle::Area &area);
  void transform_point(const VPoint &point_in,VPoint &point_out);
  void transform_pcl(const VPointCloud::ConstPtr &pcl_in,VPointCloud::Ptr pcl_out);
private:
  Lidar lidar;
  Eigen::Matrix3d rotate;
  Eigen::Vector3d offset;
  double ground_A;
  double ground_B;
  double ground_C;
  double ground_D;
  double theta_min;
  double theta_max;

  double h_thres;
  double resolution;
  size_t rows;
  size_t cols;
  double cov_thres2;
  double range_max2;

  double grid_length;
  double grid_width;
}; //class Detect
} //namespace Lidar
#endif