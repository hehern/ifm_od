/**
	*area.cpp
	*brief:calculate area of obstacle detection
	*author:Jianlin Zhang
	*date:20170617
	**/

#include "area.h"

namespace Vehicle
{
const double very_little=0.00001;
Area::Area(ros::NodeHandle node_handle, ros::NodeHandle private_node_handle, std::string area_prefix)
{
  private_node_handle.param(area_prefix + "_min", x_min, 0.0);
  private_node_handle.param(area_prefix + "_max", x_max, 10.0); //x_max=x_max_base+k_v*std::abs(velocity)-k_s*fabs(steer)*0.035
  private_node_handle.param(area_prefix + "_max", x_max_base, 10.0);
  private_node_handle.param(area_prefix + "_k_v", k_v, 0.0);  //x_max=x_max_base+k_v*std::abs(velocity)-k_s*fabs(steer)*0.035
  private_node_handle.param(area_prefix + "_k_s", k_s, 0.0);  //x_max=x_max_base+k_v*std::abs(velocity)-k_s*fabs(steer)*0.035
  private_node_handle.param(area_prefix + "_width", y_max, 2.0);
  y_max *= 0.5;
  y_min = -y_max;
  private_node_handle.param(area_prefix + "_min_height", z_min, -0.05);
  private_node_handle.param(area_prefix + "_max_height", z_max, 3.0);
  private_node_handle.param("wheelbase", wheelbase, 2.0);
  private_node_handle.param("front_overhang", front_overhang, 0.5);
  private_node_handle.param("segment", segment, 8);
  private_node_handle.param("vehicle_frame_id", frame_id, std::string("vehicle"));

  danger_level = 0;
} //Area::Area(ros::NodeHandle node_handle, ros::NodeHandle private_node_handle)

void Area::update(double curvature_V_new)
{
  curvature_V = curvature_V_new;
  if (curvature_V > very_little) //turning left
  {
    double temp = sqrt(1 - curvature_V * curvature_V * wheelbase * wheelbase);
    curvature_in = curvature_V / (temp - curvature_V * y_max);
    curvature_mid = curvature_in/sqrt(1+curvature_in*curvature_in*(wheelbase+front_overhang+x_min)*(wheelbase+front_overhang+x_min));
    if (curvature_in * (x_min + wheelbase + front_overhang) > 1)
    {
      curvature_in = 1 / (x_min + wheelbase + front_overhang);
    }
    temp = (temp + curvature_V * y_max) * (temp + curvature_V * y_max);
    temp += curvature_V * curvature_V * (wheelbase + front_overhang + x_min) * (wheelbase + front_overhang + x_min);
    curvature_out = curvature_V / sqrt(temp);
  }
  else if (curvature_V < -very_little) //turning right
  {
    double temp = sqrt(1 - curvature_V * curvature_V * wheelbase * wheelbase);
    curvature_in = curvature_V / (temp - curvature_V * y_min);
    curvature_mid = curvature_in/sqrt(1+curvature_in*curvature_in*(wheelbase+front_overhang+x_min)*(wheelbase+front_overhang+x_min));
    if (-curvature_in * (x_min + wheelbase + front_overhang) > 1)
    {
      curvature_in = -1 / (x_min + wheelbase + front_overhang);
    }
    temp = (temp - curvature_V * y_max) * (temp - curvature_V * y_max);
    temp += curvature_V * curvature_V * (wheelbase + front_overhang + x_min) * (wheelbase + front_overhang + x_min);
    curvature_out = curvature_V / sqrt(temp);
  }
  else //going straight
  {
    curvature_in = 0;
    curvature_out = 0;
  }
} //void Area::update(double curvature_V)

void Area::update(double curvature_V_new,double velocity)
{
  update(curvature_V_new);
  x_max=x_max_base+k_v*std::abs(velocity);
} //void Area::update(double curvature_V,double velocity)

void Area::update(double curvature_V_new,double velocity,double steer)
{
  x_max=x_max_base+k_v*std::abs(velocity)-k_s*fabs(steer)*0.035;  //the constant 0.035 is used to convert unit of k_s
  if(x_max<0.7*x_max_base)
  {
    x_max=0.7*x_max_base;
  }
  update(curvature_V_new);
} //void Area::update(double curvature_V,double velocity,double steer)

bool Area::is_in(double x, double y, double z)
{
  if(std::isnan(x)||std::isnan(y)||std::isnan(z))     //Is Not-A-Number
  {
    return false;
  }
  else if ((z > z_max) || (z < z_min))                //点的坐标在设置值外的话，返回
  {
    return false;
  }
  else if (curvature_V > very_little) //turning left
  {
    double temp = sqrt(1 - curvature_V * curvature_V * wheelbase * wheelbase);
    double temp2 = curvature_V * (x + wheelbase + front_overhang);
    double temp3 = temp2 * temp2 + (curvature_V * y - temp) * (curvature_V * y - temp);
    // if (temp3 * curvature_in * curvature_in - curvature_V * curvature_V < 0) //point is in inner circle
    if (temp3 * curvature_mid * curvature_mid - curvature_V * curvature_V < 0) //point is in middle circle
    {
      return false;
    }
    else if (temp3 * curvature_out * curvature_out - curvature_V * curvature_V > 0)
    {
      return false;
    }
    else
    {
      if (x < x_min)
      {
        return false;
      }
      else
      {
        double theta = x_max * curvature_out;
        double center_x = -(wheelbase + front_overhang);
        double center_y = temp / curvature_V;
        double temp_x = center_x - center_x * cos(theta) - (y_min - center_y) * sin(theta);
        double temp_y = center_y + (y_min - center_y) * cos(theta) - center_x * sin(theta);
        double D = center_y * temp_x - center_x * temp_y;
        double A = (temp_y - center_y) / D;
        double B = (center_x - temp_x) / D;
        if (A * x + B * y + 1 < 0)
        {
          return false;
        }
        else
        {
          return true;
        }
      }
    }
  }
  else if (curvature_V < -very_little) //turning right
  {
    double temp = sqrt(1 - curvature_V * curvature_V * wheelbase * wheelbase);
    double temp2 = curvature_V * (x + wheelbase + front_overhang);
    double temp3 = temp2 * temp2 + (curvature_V * y - temp) * (curvature_V * y - temp);
    // if (temp3 * curvature_in * curvature_in - curvature_V * curvature_V < 0) //point is in inner circle
    if (temp3 * curvature_mid * curvature_mid - curvature_V * curvature_V < 0) //point is in middle circle
    {
      return false;
    }
    else if (temp3 * curvature_out * curvature_out - curvature_V * curvature_V > 0)
    {
      return false;
    }
    else
    {
      if (x < x_min)
      {
        return false;
      }
      else
      {
        double theta = x_max * curvature_out;
        double center_x = -(wheelbase + front_overhang);
        double center_y = temp / curvature_V;
        double temp_x = center_x - center_x * cos(theta) - (y_max - center_y) * sin(theta);
        double temp_y = center_y + (y_max - center_y) * cos(theta) - center_x * sin(theta);
        double D = center_y * temp_x - center_x * temp_y;
        double A = (temp_y - center_y) / D;
        double B = (center_x - temp_x) / D;
        if (A * x + B * y + 1 < 0)
        {
          return false;
        }
        else
        {
          return true;
        }
      }
    }
  }
  else //going straight
  {
    if ((x > x_max) || (x < x_min))
    {
      return false;
    }
    else if ((y > y_max) || (y < y_min))
    {
      return false;
    }
    else
    {
      return true;
    }
  }
}

void Area::draw(ros::Publisher &area_draw_publisher)
{
  visualization_msgs::Marker::Ptr line_list(new visualization_msgs::Marker);
  line_list->header.frame_id = frame_id;
  line_list->header.stamp = ros::Time::now();
  line_list->ns = frame_id;
  line_list->action = visualization_msgs::Marker::ADD;
  line_list->pose.orientation.w = 1.0;
  line_list->id = 2;
  line_list->type = visualization_msgs::Marker::LINE_LIST;
  if (danger_level & 0x01)
  {
  	line_list->color.r = 1.0;
  	line_list->color.g = 0.0;
  	line_list->color.b = 0.0;
    line_list->color.a = 0.5;
  }
  else if(danger_level & 0x02)
  {
  	line_list->color.r = 1.0;
  	line_list->color.g = 1.0;
  	line_list->color.b = 0.0;
  	line_list->color.a = 1.0;
  }
  else if(danger_level & 0x04)
  {
  	line_list->color.r = 1.0;
  	line_list->color.g = 1.0;
  	line_list->color.b = 0.0;
    line_list->color.a = 0.5;
  }
  else
  {
  	line_list->color.r = 0.0;
  	line_list->color.g = 1.0;
  	line_list->color.b = 0.0;
    line_list->color.a = 0.5;
  }
  line_list->scale.x = 0.05;
  line_list->scale.y = 0.05;
  line_list->scale.z = 0.05;
  if ((curvature_V > -very_little)&&(curvature_V < very_little)) //car is running straight
  {
    draw_cuboid(line_list, x_min, y_min, z_min, x_max, y_max, z_max);
  }
  else if (curvature_V >= very_little) //turning left
  {
    double temp = sqrt(1 - curvature_V * curvature_V * wheelbase * wheelbase);
    double theta = x_max * curvature_out;
    double center_x = -(wheelbase + front_overhang);
    double center_y = temp / curvature_V;
    double temp_x = center_x - center_x * cos(theta) - (y_min - center_y) * sin(theta);
    double temp_y = center_y + (y_min - center_y) * cos(theta) - center_x * sin(theta);
#if IS_SHOW_INNER_CIRCLE
    double temp_2 = sqrt(1 - curvature_in * curvature_in * (x_min + front_overhang + wheelbase) * (x_min + front_overhang + wheelbase));
    double temp_y_2 = y_max + (1 - temp_2) / curvature_in; //this line will widen the area's width
    double temp_x_3 = curvature_out * (temp_x - center_x) / curvature_in + center_x;
    double temp_y_3 = curvature_out * (temp_y - center_y) / curvature_in + center_y;
#else //show middle circle
    double temp_y_2 = y_max;  //this line will not widden the area's width
    double temp_x_3 = curvature_out * (temp_x - center_x) / curvature_mid + center_x;
    double temp_y_3 = curvature_out * (temp_y - center_y) / curvature_mid + center_y;
#endif
    //Note: the range of acos is [0,M_PI],so theta_2 must be compensated
    double theta_2 = (temp_y_2 - center_y) * (temp_y_3 - center_y) + (0 - center_x) * (temp_x_3 - center_x);
    theta_2 /= (temp_y_2 - center_y) * (temp_y_2 - center_y) + (0 - center_x) * (0 - center_x);
    theta_2 = acos(theta_2);
    if(temp_x_3<0)
    {
      theta_2=2*M_PI-theta_2;
    }
    draw_square(line_list, x_min, y_min, z_min, x_min, temp_y_2, z_max);
    draw_square(line_list, temp_x_3, temp_y_3, z_min, temp_x, temp_y, z_max);
    draw_arc(line_list, center_x, center_y, x_min, y_min, z_min, theta, segment);
    draw_arc(line_list, center_x, center_y, x_min, y_min, z_max, theta, segment);
    draw_arc(line_list, center_x, center_y, x_min, temp_y_2, z_min, theta_2, segment);
    draw_arc(line_list, center_x, center_y, x_min, temp_y_2, z_max, theta_2, segment);
  }
  else //turning right
  {
    double temp = sqrt(1 - curvature_V * curvature_V * wheelbase * wheelbase);
    double theta = x_max * curvature_out;
    double center_x = -(wheelbase + front_overhang);
    double center_y = temp / curvature_V;
    double temp_x = center_x - center_x * cos(theta) - (y_max - center_y) * sin(theta);
    double temp_y = center_y + (y_max - center_y) * cos(theta) - center_x * sin(theta);
#if IS_SHOW_INNER_CIRCLE
    double temp_2 = sqrt(1 - curvature_in * curvature_in * (x_min + front_overhang + wheelbase) * (x_min + front_overhang + wheelbase));
    double temp_y_2 = y_min + (1 - temp_2) / curvature_in; //this line will widen the area's width
    double temp_x_3 = curvature_out * (temp_x - center_x) / curvature_in + center_x;
    double temp_y_3 = curvature_out * (temp_y - center_y) / curvature_in + center_y;
#else //show middle circle
    double temp_y_2 = y_min;  //this line will not widden the area's width
    double temp_x_3 = curvature_out * (temp_x - center_x) / curvature_mid + center_x;
    double temp_y_3 = curvature_out * (temp_y - center_y) / curvature_mid + center_y;
#endif
    //Note: the range of acos is [0,M_PI],so theta_2 must be compensated
    double theta_2 = (temp_y_2 - center_y) * (temp_y_3 - center_y) + (0 - center_x) * (temp_x_3 - center_x);
    theta_2 /= (temp_y_2 - center_y) * (temp_y_2 - center_y) + (0 - center_x) * (0 - center_x);
    theta_2 = -acos(theta_2);
    if(temp_x_3<0)
    {
      theta_2=-theta_2-2*M_PI;
    }
    draw_square(line_list, x_min, y_max, z_min, x_min, temp_y_2, z_max);
    draw_square(line_list, temp_x_3, temp_y_3, z_min, temp_x, temp_y, z_max);
    draw_arc(line_list, center_x, center_y, x_min, y_max, z_min, theta, segment);
    draw_arc(line_list, center_x, center_y, x_min, y_max, z_max, theta, segment);
    draw_arc(line_list, center_x, center_y, x_min, temp_y_2, z_min, theta_2, segment);
    draw_arc(line_list, center_x, center_y, x_min, temp_y_2, z_max, theta_2, segment);
  }
  area_draw_publisher.publish(line_list);
} //void Area::draw(ros::Publisher &area_draw_publisher)

void Area::set_danger_level(unsigned int danger_level_new)
{
  danger_level=danger_level_new;
} //void Area::set_danger_level(unsigned int danger_level_new)

} //namespace Vehicle
