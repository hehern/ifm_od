/**
  *top.cpp
  *brief:top layer of software, ROS plantform related part
  *author:Jianlin Zhang
  *date:20171031
  **/

#include "top.h"

namespace Vehicle
{
Top::Top(ros::NodeHandle node_handle, ros::NodeHandle private_node_handle)
    : vehicle(node_handle, private_node_handle),
      detect(node_handle, private_node_handle, "front_lidar"),
      collision_detect(node_handle, private_node_handle),
      slow_area_1(node_handle, private_node_handle, "slow_1"),
      slow_area_2(node_handle, private_node_handle, "slow_2"),
      stop_area(node_handle, private_node_handle, "stop"),
      stop_area_2(node_handle, private_node_handle, "stop_2")
{
  std::string topic;
  int queue_size;

  private_node_handle.param("CAN_sent_topic", topic, std::string("sent_messages"));
  can_publisher = node_handle.advertise<can_msgs::Frame>(topic, queue_size);

  private_node_handle.param("ros_default_queue_size", queue_size, 1);
  private_node_handle.param("is_displaying", is_displaying, true);
  private_node_handle.param("is_online_running", is_online_running, true);
  if (is_displaying)
  {
    private_node_handle.param("vehicle_frame_id", frame_id, std::string("vehicle"));

    private_node_handle.param("vehicle_draw_topic", topic, std::string("vehicle"));
    vehicle_draw_publisher = node_handle.advertise<visualization_msgs::Marker>(topic, queue_size);

    private_node_handle.param("stop_area_draw_topic", topic, std::string("stop_area"));
    stop_area_draw_publisher = node_handle.advertise<visualization_msgs::Marker>(topic, queue_size);

    private_node_handle.param("stop_area_2_draw_topic", topic, std::string("stop_area_2"));
    stop_area_2_draw_publisher = node_handle.advertise<visualization_msgs::Marker>(topic, queue_size);

    private_node_handle.param("slow_area_1_draw_topic", topic, std::string("slow_area_1"));
    slow_area_1_draw_publisher = node_handle.advertise<visualization_msgs::Marker>(topic, queue_size);

    private_node_handle.param("slow_area_2_draw_topic", topic, std::string("slow_area_2"));
    slow_area_2_draw_publisher = node_handle.advertise<visualization_msgs::Marker>(topic, queue_size);

    private_node_handle.param("obstacle_pointcloud_topic", topic, std::string("obstacle_points"));
    obstacle_pointcloud_publisher = node_handle.advertise<VPointCloud>(topic, queue_size);

  }
  private_node_handle.param("CAN_received_topic", topic, std::string("/RecvCAN_1/received_can_messages"));
  can_subscriber = node_handle.subscribe(topic, queue_size, &Top::can_callback, this);

  private_node_handle.param("lidar_pointcloud_topic", topic, std::string("ifm_points"));
  pcl_subscriber = node_handle.subscribe(topic, queue_size, &Top::point_cloud_callback, this);

  vehicle.update(0, 0);
  stop_area.update(vehicle.curvature_V);
  slow_area_1.update(vehicle.curvature_V);
  slow_area_2.update(vehicle.curvature_V);
  if (is_displaying)
  {
    ros::Duration(3).sleep();
    //ROS_INFO("apple:%d",is_displaying);
    vehicle.draw_vehicle(vehicle_draw_publisher);
    stop_area.draw(stop_area_draw_publisher);
    stop_area_2.draw(stop_area_2_draw_publisher);
    slow_area_1.draw(slow_area_1_draw_publisher);
    slow_area_2.draw(slow_area_2_draw_publisher);
  }
} //Top::Top(ros::NodeHandle node_handle, ros::NodeHandle private_node_handle)

void Top::can_callback(const can_msgs::Frame::ConstPtr &rec)     //收到车辆信息topic
{
  if (rec->id == 0x182) //SpeedMilSteer's frame
  {
    //ROS_INFO("can_callback");
    double steering;        //方向盘角度
    double velocity;        //车辆速度
    steering = (static_cast<short>(rec->data[0]) |
                static_cast<short>(rec->data[1] << 8)) *
               0.1;
    steering *= M_PI / 180;
    velocity = (static_cast<short>(rec->data[2]) |
                static_cast<short>(rec->data[3] << 8)) *
               0.001;
    vehicle.update(steering, velocity);                            //
    stop_area.update(vehicle.curvature_V,velocity,steering);
    stop_area_2.update(vehicle.curvature_V,velocity,steering);
    slow_area_1.update(vehicle.curvature_V,velocity,steering);
    slow_area_2.update(vehicle.curvature_V,velocity,steering);
    if (is_displaying)
    {
      stop_area.draw(stop_area_draw_publisher);
      stop_area_2.draw(stop_area_2_draw_publisher);
      slow_area_1.draw(slow_area_1_draw_publisher);
      slow_area_2.draw(slow_area_2_draw_publisher);
    }
  }
  else if(rec->id==0x26)
  {
    unsigned long status=0;
    for(size_t i=0;i<8;++i)
    {
      status|=(static_cast<unsigned long>(rec->data[i])<<(i*8));
    }
    status+=static_cast<unsigned long>(rec->header.stamp.nsec)*3141592653UL;
    if(status!=0xffffffffffffffff)
    {
      collision_detect.pub_error_to_CAN(can_publisher);
      status=(~status)&0xffffffffffffffff;
      std::cerr<<std::hex<<"error code:"<<status<<std::endl;
    }
  }
} //void Top::can_callback(const can_msgs::Frame::ConstPtr &rec)

void Top::point_cloud_callback(const VPointCloud::ConstPtr &rec)   //收到激光雷达发出的点云topic
{
  //ROS_INFO("point_callback");
  //if(vehicle.velocity>=0)                                         //行驶过程中
  //{
    VPointCloud::Ptr obstacle_pointcloud(new VPointCloud());      //建立点云对象
    detect.transform_pcl(rec,obstacle_pointcloud);
    detect.remove_ground(rec,obstacle_pointcloud);                //去除地面点云数据第一次
    //detect.remove_ground(rec,obstacle_pointcloud,slow_area_2);    //去除地面点云数据第二次
    std::cout << "i am here" << std::endl;
    //collision_detect.update(obstacle_pointcloud, &stop_area, &slow_area_1, &slow_area_2, &stop_area_2); //碰撞检测更新，判断避障区域内点的个数
    if (is_displaying)
    {
      obstacle_pointcloud->header.frame_id = frame_id;
      if (obstacle_pointcloud->width > 0)
      {
         obstacle_pointcloud_publisher.publish(obstacle_pointcloud);
      }
    }
 /* }
  else                                                            //停车状态下，清空点云数据
  {
    VPointCloud::Ptr empty_pointcloud(new VPointCloud());
    collision_detect.update(empty_pointcloud, &stop_area, &slow_area_1, &slow_area_2, &stop_area_2);
  }
  collision_detect.pub_result_to_CAN(can_publisher);     //将指令通过CAN发出*/
}
} //namespace vehicle
