/**
	*vehicle.cpp
	*brief:draw car in rviz
	*author:Jianlin Zhang
	*date:20170608
	**/

#include "vehicle.h"

namespace Vehicle
{
Vehicle::Vehicle(ros::NodeHandle node_handle, ros::NodeHandle private_node_handle)
{
  private_node_handle.param("wheelbase", wheelbase, 2.0);
  private_node_handle.param("front_overhang", front_overhang, 0.5);
  private_node_handle.param("rear_overhang", rear_overhang, 0.5);
  private_node_handle.param("width", width, 1.5);
  private_node_handle.param("height", height, 2.0);
  private_node_handle.param("vehicle_frame_id", frame_id, std::string("vehicle"));
  private_node_handle.param("ackerman_rate", ackerman_rate, 0.05);
  private_node_handle.param("steer_offset", steer_offset, 0.0);
  steer_offset*=M_PI/180.0;
}

void Vehicle::draw_vehicle(ros::Publisher &vehicle_draw_publisher) //draw vehicle in rviz
{
  // while (vehicle_draw_publisher.getNumSubscribers() == 0)
  //   ; //if no subscriber, do not publish
  visualization_msgs::Marker::Ptr line_list(new visualization_msgs::Marker);
  //initialize line list;
  line_list->header.frame_id = frame_id;                                //帧ID
  line_list->header.stamp = ros::Time::now();                           //时间戳
  line_list->ns = frame_id;                                             //命名空间
  line_list->action = visualization_msgs::Marker::ADD;
  line_list->pose.orientation.w = 1.0;                                  //位姿，四元数
  line_list->id = 1;
  line_list->type = visualization_msgs::Marker::LINE_LIST;              //类型为线
  line_list->color.r = 1.0;
  line_list->color.g = 1.0;
  line_list->color.b = 1.0;
  line_list->color.a = 0.5;
  // LINE_STRIP/LINE_LIST markers use only the x component of scale, for the line width
  line_list->scale.x = 0.05;
  line_list->scale.y = 0.05;
  line_list->scale.z = 0.05;
  draw_cuboid(line_list, 0, width * 0.5, 0, -(wheelbase + front_overhang + rear_overhang), -width * 0.5, height);
  vehicle_draw_publisher.publish(line_list);
} //void Vehicle::draw_vehicle(ros::Publisher &vehicle_draw_publisher)

void Vehicle::update(double steering_new, double velocity_new)
{
  steering=steering_new*ackerman_rate+steer_offset;
  velocity=velocity_new;
  curvature_V=sin(steering)/wheelbase;
} //void Vehicle::update(double steer_new, double velocity_new)

} //namespace Vehicle
