/**
  *collision_detect.h
  *brief:judge if collision will happen
  *author:Jianlin Zhang
  *date:20171213
  **/

#ifndef COLLISION_DETECT_H
#define COLLISION_DETECT_H

#include <can_msgs/Frame.h>
#include "velodyne.h"
#include "area.h"

namespace Vehicle
{
class Collision_detect
{
public:
  Collision_detect(ros::NodeHandle node_handle, ros::NodeHandle private_node_handle);
  template<typename Area>
  void update(VPointCloud::Ptr obstacle_pointcloud,Area *p_stop,Area *p_slow_1,Area *p_slow_2)
  {
    size_t stop_count = 0;
    size_t slow_1_count = 0;
    size_t slow_2_count = 0;
    for (const VPoint &p : obstacle_pointcloud->points)
    {
      if (p_stop->is_in(p.x, p.y, p.z))
      {
        ++stop_count;
      }
      if (p_slow_1->is_in(p.x, p.y, p.z))
      {
        ++slow_1_count;
      }
      if (p_slow_2->is_in(p.x, p.y, p.z))
      {
        ++slow_2_count;
      }
    }
    danger_level = ((slow_2_count > slow_2_num_set) << 2) |
                  ((slow_1_count > slow_1_num_set) << 1) |
                  (stop_count > stop_num_set);
    p_stop->set_danger_level(danger_level);
    p_slow_1->set_danger_level(danger_level);
    p_slow_2->set_danger_level(danger_level);
  }; //void Collision_detect::update(VPointCloud::Ptr obstacle_pointcloud,
  template<typename Area>
  void update(VPointCloud::Ptr obstacle_pointcloud,Area *p_stop,Area *p_slow_1,Area *p_slow_2,Area *p_stop_2)
  {
    if(obstacle_pointcloud->width>0)
    {
      size_t stop_count = 0;
      size_t stop_2_count = 0;
      size_t slow_1_count = 0;
      size_t slow_2_count = 0;
      for (const VPoint &p : obstacle_pointcloud->points)
      {
        if (p_stop->is_in(p.x, p.y, p.z))
        {
          ++stop_count;
        }
        if (p_stop_2->is_in(p.x, p.y, p.z))
        {
          ++stop_2_count;
        }
        if (p_slow_1->is_in(p.x, p.y, p.z))
        {
          ++slow_1_count;
        }
        if (p_slow_2->is_in(p.x, p.y, p.z))
        {
          ++slow_2_count;
        }
      }
      danger_level = ((slow_2_count > slow_2_num_set) << 2) |
                    ((slow_1_count > slow_1_num_set) << 1) |
                    ((stop_2_count > stop_2_num_set) << 3) |
                    (stop_count > stop_num_set)|
                    (stop_2_count > stop_2_num_set);
    }
    else
    {
      danger_level = 0x0f;
    }
    p_stop->set_danger_level(danger_level);
    p_slow_1->set_danger_level(danger_level);
    p_slow_2->set_danger_level(danger_level);
    p_stop_2->set_danger_level(danger_level);
  }; //void Collision_detect::update(VPointCloud::Ptr obstacle_pointcloud,
  void pub_result_to_CAN(ros::Publisher &can_publisher);
  void pub_error_to_CAN(ros::Publisher &can_publisher);
  void pub_rear_result_to_CAN(ros::Publisher &can_publisher);
  void pub_rear_error_to_CAN(ros::Publisher &can_publisher);

private:
  int can_sent_id;
  int stop_num_set;
  int stop_2_num_set;
  int slow_1_num_set;
  int slow_2_num_set;
  unsigned int danger_level;
}; //class Collision_detect

} //namespace vehicle
#endif