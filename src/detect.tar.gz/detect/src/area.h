/**
	*area.h
	*brief:calculate area of obstacle detection
	*author:Jianlin Zhang
	*date:20170617
	**/

#ifndef AREA_H
#define AREA_H

#define _USE_MATH_DEFINES //use constant number defined in math.h
#include <cmath>
#include <iostream>

#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include "draw.h"

#define IS_SHOW_INNER_CIRCLE false

namespace Vehicle
{
// const double very_little=0.00001;
class Area
{
public:
  Area(ros::NodeHandle node_handle, ros::NodeHandle private_node_handle, std::string area_prefix);
  ~Area(){};
  void update(double curvature_V_new);
  void update(double curvature_V_new,double velocity);
  void update(double curvature_V_new,double velocity,double steer);
  bool is_in(double x, double y, double z);
  void draw(ros::Publisher &area_draw_publisher);
  void set_danger_level(unsigned int danger_level_new);

private:
  //setting parameters
  double wheelbase;
  double front_overhang;
  int segment; //segment to draw radius by line list
  double x_min;
  double x_max;
  double x_max_base;
  double k_v; //x_max = x_max_base + k_v*v - k_s*fabs(steer)
  double k_s; //x_max = x_max_base + k_v*v - k_s*fabs(steer)
  double y_min;
  double y_max;
  double z_min;
  double z_max;
  //status
  double curvature_V; //turnning curvature of vehicle          车辆转向曲率
  double curvature_in;//inner turnning circle curvature        内轨道转向曲率
  double curvature_out; //outer turnning circle curvature      外轨道转向曲率
  double curvature_mid; //the front inner corner of vehicle curvature while turnning
  unsigned int danger_level;  //color will be changed by danger level    颜色随危险等级变化
  //ros related variable
  std::string frame_id;
}; //class Area
} //namespace Vehicle
#endif