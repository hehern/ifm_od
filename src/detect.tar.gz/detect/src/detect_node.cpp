/**
	*detect_node.cpp
	*brief:implement of lidar processer
	*author:Jianlin Zhang
	*date:20171128
	**/

#include "top.h"

int main(int argc, char ** argv)
{
  ros::init(argc,argv,"detect_node");
	ros::NodeHandle node_handle;
	ros::NodeHandle privete_node_handle("~");
  Vehicle::Top top(node_handle,privete_node_handle);
	ros::spin();
  return 0;
}