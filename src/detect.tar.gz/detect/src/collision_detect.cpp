/**
  *collision_detect.cpp
  *brief:judge if collision will happen
  *author:Jianlin Zhang
  *date:20171213
  **/

#include "collision_detect.h"

namespace Vehicle
{
Collision_detect::Collision_detect(ros::NodeHandle node_handle, ros::NodeHandle private_node_handle)
{
  private_node_handle.param("can_sent_id", can_sent_id, 0x083);
  private_node_handle.param("stop_num_set", stop_num_set, 5);
  private_node_handle.param("stop_2_num_set", stop_2_num_set, 5);
  private_node_handle.param("slow_1_num_set", slow_1_num_set, 5);
  private_node_handle.param("slow_2_num_set", slow_2_num_set, 5);
} //Collision_detect::Collision_detect(ros::NodeHandle node_handle, ros::NodeHandle private_node_handle)

void Collision_detect::pub_result_to_CAN(ros::Publisher &can_publisher)
{
  can_msgs::Frame::Ptr result(new can_msgs::Frame());
  result->header.stamp = ros::Time::now();
  result->id = can_sent_id;
  result->is_rtr = false;
  result->is_extended = false;
  result->dlc = 8;
  result->data[0] = ~danger_level;
  result->data[1] = 0xff;
  result->data[2] = 0xff;
  result->data[3] = 0xff;
  result->data[4] = 0xff;
  result->data[5] = 0xff;
  result->data[6] = 0xff;
  result->data[7] = 0xff;
  can_publisher.publish(result);
} //void Collision_detect::pub_result_to_CAN(ros::Publisher &can_publisher)

void Collision_detect::pub_error_to_CAN(ros::Publisher &can_publisher)
{
  can_msgs::Frame::Ptr result(new can_msgs::Frame());
  result->header.stamp = ros::Time::now();
  result->id = can_sent_id;
  result->is_rtr = false;
  result->is_extended = false;
  result->dlc = 8;
  result->data[0] = 0x00;
  result->data[1] = 0xff;
  result->data[2] = 0xff;
  result->data[3] = 0xff;
  result->data[4] = 0xff;
  result->data[5] = 0xff;
  result->data[6] = 0xff;
  result->data[7] = 0xff;
  can_publisher.publish(result);
} //void Collision_detect::pub_error_to_CAN(ros::Publisher &can_publisher)

void Collision_detect::pub_rear_result_to_CAN(ros::Publisher &can_publisher)
{
  can_msgs::Frame::Ptr result(new can_msgs::Frame());
  result->header.stamp = ros::Time::now();
  result->id = can_sent_id;
  result->is_rtr = false;
  result->is_extended = false;
  result->dlc = 8;
  result->data[0] = ~danger_level;
  result->data[1] = 0xff;
  result->data[2] = 0xff;
  result->data[3] = 0xff;
  result->data[4] = 0xff;
  result->data[5] = 0xff;
  result->data[6] = 0xff;
  result->data[7] = 0xff;
  can_publisher.publish(result);
} //void Collision_detect::pub_rear_result_to_CAN(ros::Publisher &can_publisher)

void Collision_detect::pub_rear_error_to_CAN(ros::Publisher &can_publisher)
{
  can_msgs::Frame::Ptr result(new can_msgs::Frame());
  result->header.stamp = ros::Time::now();
  result->id = can_sent_id;
  result->is_rtr = false;
  result->is_extended = false;
  result->dlc = 8;
  result->data[0] = 0x00;
  result->data[1] = 0xff;
  result->data[2] = 0xff;
  result->data[3] = 0xff;
  result->data[4] = 0xff;
  result->data[5] = 0xff;
  result->data[6] = 0xff;
  result->data[7] = 0xff;
  can_publisher.publish(result);
} //void Collision_detect::pub_rear_error_to_CAN(ros::Publisher &can_publisher)

} //namespace vehicle