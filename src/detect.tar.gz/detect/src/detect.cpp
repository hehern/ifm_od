/**
  *detect.cpp
  *brief: detect obstacle via lidar
  *author:Jianlin Zhang
  *date:20180521
  **/

#include "detect.h"

namespace Lidar
{
Detect::Detect(ros::NodeHandle nh, ros::NodeHandle pnh, std::string prefix)
{
  double temp;
  pnh.param(prefix+"_roll", temp, 0.0);//横滚   绕车坐标系的X旋转
  lidar.roll=temp*M_PI/180.0;
  pnh.param(prefix+"_pitch", temp, 0.0);//俯仰角  绕车坐标系下旋转后的Y轴旋转
  lidar.pitch=temp*M_PI/180.0;
  pnh.param(prefix+"_yaw", temp, 0.0);//偏航角    绕车坐标系下旋转后的Z轴旋转
  lidar.yaw=temp*M_PI/180.0;
  pnh.param(prefix+"_x", temp, 0.0);
  offset(0)=temp;
  lidar.x=temp;                  //摄像头在车的坐标系中的位置
  pnh.param(prefix+"_y", temp, 0.0);
  offset(1)=temp;
  lidar.y=temp;
  pnh.param(prefix+"_z", temp, 0.0);
  offset(2)=temp;
  lidar.z=temp;

  Eigen::Vector3d v_r(1,0,0);      //正交基，作为基向量
  Eigen::Vector3d v_p(0,1,0);
  Eigen::Vector3d v_y(0,0,1);
  v_r*=sin(lidar.roll/2);                                            //这是坐标转换吗？
  v_p*=sin(lidar.pitch/2);
  v_y*=sin(lidar.yaw/2);
  Eigen::Quaterniond q_r(cos(lidar.roll/2),v_r(0),v_r(1),v_r(2)); //四元数
  Eigen::Quaterniond q_p(cos(lidar.pitch/2),v_p(0),v_p(1),v_p(2));
  Eigen::Quaterniond q_y(cos(lidar.yaw/2),v_y(0),v_y(1),v_y(2));
  rotate=q_y.toRotationMatrix()*q_p.toRotationMatrix()*q_r.toRotationMatrix();//四元数转换为旋转矩阵，由车的坐标系向摄像头的坐标系的转换
  ground_A=rotate(2,0);
  ground_B=rotate(2,1);
  ground_C=rotate(2,2);
  ground_D=lidar.z;
  
  int temp2;
  pnh.param(prefix+"_beams", temp2, 16);
  lidar.beams=temp2;
  pnh.param(prefix+"_points_per_beam", temp2, 64);
  lidar.points_per_beam=temp2;
  rows=(lidar.beams);
  cols=(lidar.points_per_beam);
  //resolution=2*M_PI/lidar.points_per_beam;

  //pnh.param(prefix+"_theta_min", theta_min, 0.0);
  //theta_min*=M_PI/180;
  //pnh.param(prefix+"_theta_max", theta_max, 360.0);
  //theta_max*=M_PI/180;
  //parameter for ground removing
  double range_max;
  double cov_thres;
  pnh.param(prefix+"_range_max", range_max, 100.0);
  range_max2=range_max*range_max;
  pnh.param(prefix+"_cov_thres", cov_thres, 0.05);//协方差
  cov_thres2=cov_thres*cov_thres;
  pnh.param(prefix+"_h_thres", h_thres, 0.05);  //最低检测高度
  
  //parameter for ground removing via grid
  pnh.param(prefix+"_grid_length", grid_length, 0.1);
  pnh.param(prefix+"_grid_width", grid_width, 0.1);
}
void Detect::transform_point(const VPoint &point_in,VPoint &point_out)
{
  if(std::isfinite(point_in.x))
  {
    Eigen::Vector3d lhs(point_in.x,point_in.y,point_in.z);
    Eigen::Vector3d rhs=rotate*lhs+offset;
    point_out.x=rhs(0);
    point_out.y=rhs(1);
    point_out.z=rhs(2);
  }
  else
  {
    point_out=point_in;
  }
} //void Detect::transform_point(const T &point_in,T &point_out)
void Detect::transform_pcl(const VPointCloud::ConstPtr &pcl_in,VPointCloud::Ptr pcl_out)
{
  if(pcl_in->width>0)
  {
    VPoint pt;
    for(const VPoint &p:pcl_in->points)
    {
      transform_point(p,pt);
      if(std::isfinite(pt.x))
      {
        pcl_out->points.push_back(pt);
        ++pcl_out->width;
      }
    }
    pcl_out->height=1;
  }
} //void Detect::transform_pcl(boost::shared_ptr< pcl::PointCloud<T> const> pcl_in,
void Detect::remove_ground(const VPointCloud::ConstPtr &pcl_in,VPointCloud::Ptr pcl_out)
{
  
  if(pcl_in->width>0)
  {
    double height[rows][cols];
    double height2[rows][cols];
    VPoint points[rows][cols];
    for(size_t i=0;i<rows;++i)
    {
      for(size_t j=0;j<cols;++j)
      {
        height[i][j]=0;
        points[i][j].x=0;
        points[i][j].y=0;
        points[i][j].z=0;
      }
    }
    VPoint p;
    size_t row_point;
    size_t col_point;
    for(size_t i=0;i<pcl_in->width;++i)
    {
      row_point = i/64;
      col_point = i%64;
      p = pcl_in->points[i];
      double h=ground_A*p.x+ground_B*p.y+ground_C*p.z+ground_D;//h为点到平面的距离
      points[row_point][col_point]=p;
      height[row_point][col_point]=h;
      height2[row_point][col_point]=h*h;
    }
    VPoint pt;
    for(size_t i=0;i<rows-2;++i)
    {
      for(size_t j=0;j<cols-2;++j)
      {
        double sum_x=0;
        double sum_xx=0;
        size_t none_zero_count=0;
        size_t max_h_m=0;
        size_t max_h_n=0;
        for(size_t m=0;m<3;++m)
        {
          for(size_t n=0;n<3;++n)
          {
            if(height[i+m][j+n]!=0)
            {
              ++none_zero_count;
              sum_x+=height[i+m][j+n];
              sum_xx+=height2[i+m][j+n];
              if(height[i+m][j+n]>height[i+max_h_m][j+max_h_n])
              {
                max_h_m=m;
                max_h_n=n;
              }
            }
          }
        }
        if(none_zero_count>0)
        {
          if((height[i][j]>h_thres)||
            (sum_xx*none_zero_count-sum_x*sum_x>cov_thres2*none_zero_count*none_zero_count))
          {
            // transform_point(points[i+1][j],pt);
            transform_point(points[i+max_h_m][j+max_h_n],pt);
            pcl_out->points.push_back(pt);
            ++pcl_out->width;
          }
        }
      }
    }
    pcl_out->height=1;
  }
}
void Detect::remove_ground(const VPointCloud::ConstPtr &pcl_in,VPointCloud::Ptr pcl_out,Vehicle::Area &area)
{
  if(pcl_in->width>0)
  {
    VPointCloud pcl_ground;
    double x_min=10.0;
    double y_min=0;
    double x_max=0;
    double y_max=0;
    VPoint pt;
    // ROS_INFO("selecting points in area");
    for(const VPoint &p:pcl_in->points)
    {
      transform_point(p,pt);
      if(area.is_in(pt.x,pt.y,pt.z))
      {
        pcl_ground.points.push_back(pt);
        x_max=fmax(pt.x,x_max);
        y_max=fmax(pt.y,y_max);
        x_min=fmin(pt.x,x_min);
        y_min=fmin(pt.y,y_min);
      }
    }
    if((pcl_ground.points.size()>0)&&(x_max>x_min)&&(y_max>y_min)) //Bugfix for null points
    {
      const size_t grid_cols=ceil((x_max-x_min)/grid_length); //here will be BUG!! if(x_max-xmin)<0
      const size_t grid_rows=ceil((y_max-y_min)/grid_width);
      double height[grid_cols][grid_rows];
      double height2[grid_cols][grid_rows];
      bool is_obstacle[grid_cols][grid_rows];
      size_t points_count[grid_cols][grid_rows];
      // ROS_INFO("initialize all array:%zu,%zu",grid_cols,grid_rows);
      for(size_t i=0;i<grid_cols;++i)
      {
        for(size_t j=0;j<grid_rows;++j)
        {
          height[i][j]=0;
          height2[i][j]=0;
          points_count[i][j]=0;
          is_obstacle[i][j]=false;
        }
      }
      // ROS_INFO("statistic height");  
      for(VPoint &p:pcl_ground.points)
      {
        size_t j=floor((p.y-y_min)/grid_width);
        size_t i=floor((p.x-x_min)/grid_length);
        height[i][j]+=p.z;
        height2[i][j]+=p.z*p.z;
        ++points_count[i][j];
      }
      // ROS_INFO("judging");  
      for(size_t i=0;i<grid_cols;++i)
      {
        for(size_t j=0;j<grid_rows;++j)
        {
          if(points_count[i][j]>3)
          {
            if((height[i][j]>h_thres*points_count[i][j])||
              (height2[i][j]*points_count[i][j]-height[i][j]*height[i][j]>cov_thres2*points_count[i][j]*points_count[i][j]))
            {
              is_obstacle[i][j]=true;
            }
          }
        }
      }
      // ROS_INFO("collecting points");  
      for(const VPoint &p:pcl_ground.points)
      {
        size_t i=static_cast<size_t>(p.ring);
        size_t j=static_cast<size_t>(p.intensity);
        if((i<grid_cols)&&(j<grid_rows)&&(is_obstacle[i][j]))
        {
          pcl_out->points.push_back(p);
          ++pcl_out->width;
        }
      }
      if(pcl_out->width==0)
      {
        VPoint p;
        p.x=lidar.x;
        p.y=lidar.y;
        p.z=lidar.z;
        pcl_out->points.push_back(p);
        ++pcl_out->width;
      }
      pcl_out->height=1;
    }
  }
} 
} //namespace Lidar